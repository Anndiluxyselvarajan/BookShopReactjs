import React from 'react';
import { Component } from 'react';
import Alert from 'react-bootstrap/Alert'

class Home1 extends Component{
    render(){
        return(
<Alert variant="primary">
  <Alert.Heading><center>Welcome to Book Shop</center></Alert.Heading>
  <p>
  <center> Good friends, good books and a sleepy conscience : This is the ideal life </center>
  </p>
  <hr />
  <p>
     <b><center> Enjoy with Books </center></b>
  </p>
  
</Alert>
        )
    }
    }
    export default Home1